/* Circle Information Program */
/* insert radius and get circle information */

#include <stdio.h>

int main()
{
	/* initial variable setting */
	float radius, pi = 3.141592, arc, area;

	/* insert radius */
	printf("Radius: ");
	scanf_s("%f", &radius);

	/* calculate process */
	arc = 2 * pi * radius;
	area = pi * radius * radius;

	/* print process */	
	printf("\n");
	printf("Circle Information\n");
	printf("arc: %0.2f\n", arc);
	printf("area: %0.2f\n", area);


	return 0;
}