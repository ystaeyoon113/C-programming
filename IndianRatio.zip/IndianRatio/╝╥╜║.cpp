/* Indian Money Ratio Program */
/* calculate how much money has been added due to 2019 from 1627 */

#include <stdio.h>

int main()
{

	/* iterate and calculate money */
	float money; int year;

	for (money = 24, year = 1627; year <= 2019; year = year +1)
	{
		money = money * (1.08);
	}
	
	/* print process */
	printf("Indian's money in 2019 is...%0.0f$\n", money);

	return 0;
}