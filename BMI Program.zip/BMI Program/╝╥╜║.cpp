/* BMI Calculation Program */

#include <stdio.h>

int main()
{
	/* user input */
	float height, weight;
	
	printf("What's your height?(cm): ");
	scanf_s("%f", &height);
	height = height / 100;
	printf("What's your weight?(kg): ");
	scanf_s("%f", &weight);


	/* BMI calculation */
	float BMI;
	BMI = weight / (height * height);


	/* result selection */
	printf("Your BMI is %f, ", BMI);

	if (BMI >= 30)
	{
		printf("You are highly obesity");
	}

	else if (BMI >= 25)
	{
		printf("You are obesity");
	}
	else if (BMI >= 23.0)
	{
		printf("You are overweight");
	}
	else if (BMI >= 18.5)
	{
		printf("You are normal weight");
	}
	else
	{
		printf("You are underweight");
	}

	return 0;
}