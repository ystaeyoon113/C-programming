/*first C programming*/
/*C language greeting*/

#include <stdio.h>

int main(void)
{
	printf("************************************************************\n");
	printf("              Let's study C/C++ programming!!!                  \n");
	printf("************************************************************\n");
}