/* Meal Price Calculation */
/* Just for fun */
/* Not Precise.. just for study */

#include <stdio.h>

int main()
{
	/* initial variable setting */
	int age, price;

	/* user input */
	printf("How old are you?: ");
	scanf_s("%d", &age);

	/* calculation process */
	price = age * 365 * 3 * 3000;

	/* print process */
	printf("\n");
	printf("You have spend %d won in your meal!", price);

	return 0;
}