/* Height Output Program */
/* insert user height and print meter and centemeter */

#include <stdio.h>

int main(void)
{

	/* initial variables */
	int user,meter,centimeter;

	/* user input */
	printf("Your height? (cm): ");
	scanf_s("%d", &user);

	/* separate into meter and centimeter */
	meter = user / 100;
	centimeter = user - 100*meter;

	/* print process */
	printf("Your height is...\n");
	printf("%d m\n",meter);
	printf("%d cm\n", centimeter);

	return 0;

}
